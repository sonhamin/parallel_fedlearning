defmodule HippoAbsApi.HoonController do
    use HippoAbsApi, :controller
    alias HippoAbs.HoonContext

    action_fallback HippoAbsApi.FallbackController

    def hoon(conn, _param) do
        uploads = []
        uploads = HoonContext.top10_disease()
        IO.puts("##########")
        
        render(conn, "index.json", %{data: %{uploads: uploads}})
        
        #html conn, """
        #<HTML>
        #<HEAD>
        #<TITLE> Hello !! </TITLE> </HEAD>
        #<BODY>
        #    <h1> Hello Phoenix Web </h1>
        #</BODY>
        #</HTML>  
        #"""
    end
end
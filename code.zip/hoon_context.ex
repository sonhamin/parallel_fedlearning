defmodule HippoAbs.HoonContext do
    @moduledoc """
    context for Testing
    """
  
    @moduledoc """   
    derive {
        Jason.Encoder, only: [
        :id, :group_id, :content_type, :filename, :hash, :size,
        :user_id, :has_thumb?, :label, :inserted_at, :updated_at
        ]
    }
    """

    import Ecto.Query, warn: false
    alias HippoAbs.Repo
    alias HippoAbs.Service.ASM.Upload
    require Logger

    def list_images, do: Repo.all(Upload)

    def top10_disease() do
        IO.puts("Succeed on executing top10 disease")
        Upload
            |> select([row], %{ id: row.id, label: row.label})
            |> Repo.all
    end
end